# Post-Quantum Hybrid Encryption

This local Swing application uses ML-KEM-768 for key establishment and AES-GCM for authenticated encryption. Sender and recipient are two panels in the same window. A recipient key pair lives in memory for the current session. Keep that key pair active to decrypt its exported packages.

## Run

Use JDK 24 or newer. Open the folder containing pom.xml in VS Code and run pqc.DesktopApp, or import it into Eclipse as an existing Maven project.

From PowerShell:

```powershell
javac -encoding UTF-8 --release 24 -d target/classes (Get-ChildItem src/main/java -Recurse -Filter *.java).FullName
java -cp target/classes pqc.DesktopApp
```

With Maven, run `mvn compile` and use the same launch command.

## Five-minute demo

1. Select **Generate Key Pair** and point out the recipient public key.
2. Enter a message in **Sender** and select **Encrypt and Send**. Explain that ML-KEM establishes the shared key while AES-GCM protects the text.
3. Select **Export Package**, save to a local file, then choose **Import Package** and select the saved file.
4. Select **Decrypt** and compare the recovered text.
5. Select **Tamper and Try Decrypting**. The app modifies a copy and reports authentication failure. Select **Decrypt** again to verify that the original package still works.

The PQC1 binary file stores a four-byte format marker, a four-byte ciphertext-and-tag length (big-endian), 1,088 bytes of ML-KEM encapsulation, a 12-byte nonce, and AES-GCM ciphertext with its 16-byte tag. The plaintext limit is 1 MiB.

## Verification

Run `mvn test` for the JUnit suite. To run the same checks with only the JDK, first compile the main sources above and then run:

```powershell
javac --release 24 -cp target/classes -d target/test-classes src/test/java/pqc/PackageFileChecks.java
java -cp "target/classes;target/test-classes" pqc.PackageFileChecks
java -cp target/classes pqc.Main
```

## SoC RTL forward NTT

The included rtl/ntt_butterfly.sv is copied unchanged from your SoC archive.
Run the **Verify RTL Forward NTT** button from the project directory, or:

    java -cp target/classes pqc.NttDemo

Install Icarus Verilog and place iverilog and vvp on PATH before running.
Alternatively set executable paths:

    java -Dpqc.iverilog=C:/iverilog/bin/iverilog.exe -Dpqc.vvp=C:/iverilog/bin/vvp.exe -cp target/classes pqc.NttDemo

The bridge compiles the supplied RTL and a file-based testbench. Java schedules seven layers, with 128 butterfly requests per layer. Each layer runs in vvp, returns its outputs to Java, and feeds the following layer. Verification compares five inputs (zero, maximum residues, and three seeded random polynomials) with a pure Java reference.

This button tests the RTL-backed NTT separately. The Encrypt and Send button still uses JDK ML-KEM. Integrating RTL into actual key generation or encapsulation requires the replaceable ML-KEM backend supplied by the SoC software or another editable implementation.

Initial local validation: Java compiles. Full RTL execution requires Icarus Verilog, which was not found in this environment.
