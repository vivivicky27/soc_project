`timescale 1ns/1ps
module ntt_layer_tb;
    logic clk = 0;
    always #5 clk = ~clk;
    logic rst_n = 0, in_valid = 0;
    logic [11:0] a = 0, b = 0, zeta = 0;
    wire out_valid;
    wire [11:0] u, v;
    integer inputs, outputs, status, aa, bb, zz, count = 0;
    string input_path, output_path;
    ntt_butterfly dut (.*);
    initial begin
        if (!$value$plusargs("INPUT=%s", input_path)) $fatal(1, "Missing INPUT");
        if (!$value$plusargs("OUTPUT=%s", output_path)) $fatal(1, "Missing OUTPUT");
        inputs = $fopen(input_path, "r");
        outputs = $fopen(output_path, "w");
        if (inputs == 0 || outputs == 0) $fatal(1, "Cannot open bridge files");
        #1; rst_n = 1; #1; rst_n = 0;
        @(negedge clk); rst_n = 1;
        status = $fscanf(inputs, "%d %d %d\n", aa, bb, zz);
        while (status == 3) begin
            if (aa < 0 || aa >= 3329 || bb < 0 || bb >= 3329 || zz < 0 || zz >= 3329)
                $fatal(1, "Invalid coefficient");
            @(negedge clk); a = aa; b = bb; zeta = zz; in_valid = 1;
            @(posedge clk); #1;
            if (out_valid !== 1'b1 || ^u === 1'bx || ^v === 1'bx)
                $fatal(1, "Invalid RTL output");
            $fdisplay(outputs, "%0d %0d", u, v);
            count++;
            status = $fscanf(inputs, "%d %d %d\n", aa, bb, zz);
        end
        if (count != 128 || (status != -1 && !$feof(inputs))) $fatal(1, "Expected 128 requests");
        $fclose(inputs); $fclose(outputs);
        $finish;
    end
endmodule


