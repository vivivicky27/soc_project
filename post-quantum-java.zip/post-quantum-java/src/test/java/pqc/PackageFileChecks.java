package pqc;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;

public final class PackageFileChecks {
    public static void main(String[] args) throws Exception {
        var crypto = new CryptoService();
        var recipient = crypto.generateKeyPair();
        byte[] original = "Hello, Java! \u4f60\u597d".getBytes(StandardCharsets.UTF_8);
        var path = Files.createTempFile("pqc-check-", ".pqc");
        try {
            PackageFile.write(path, crypto.encrypt(recipient.getPublic(), original));
            var imported = PackageFile.read(path);
            if (!Arrays.equals(original, crypto.decrypt(recipient.getPrivate(), imported))) {
                throw new AssertionError("File round trip changed the message.");
            }
            System.out.println("File round trip: passed.");
            byte[] valid = Files.readAllBytes(path);
            Files.write(path, Arrays.copyOf(valid, valid.length - 1));
            expectFailure(path, "truncated");
            byte[] corrupt = valid.clone();
            corrupt[0] ^= 1;
            Files.write(path, corrupt);
            expectFailure(path, "format");
            Files.write(path, Arrays.copyOf(valid, valid.length + 1));
            expectFailure(path, "trailing");
        } finally {
            Files.deleteIfExists(path);
        }
    }

    private static void expectFailure(java.nio.file.Path path, String reason) throws IOException {
        try {
            PackageFile.read(path);
        } catch (IOException e) {
            if (!e.getMessage().contains(reason)) {
                throw e;
            }
            System.out.println("Invalid file (" + reason + "): rejected.");
            return;
        }
        throw new AssertionError("Invalid file accepted: " + reason);
    }
}
