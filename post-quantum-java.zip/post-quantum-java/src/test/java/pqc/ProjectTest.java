package pqc;

import org.junit.jupiter.api.Test;

class ProjectTest {
    @Test
    void cryptoRoundTripAndAuthenticationFailures() throws Exception {
        Main.main(new String[0]);
    }

    @Test
    void fileRoundTripAndMalformedFiles() throws Exception {
        PackageFileChecks.main(new String[0]);
    }
}
