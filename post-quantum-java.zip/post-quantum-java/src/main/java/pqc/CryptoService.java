package pqc;

import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.Cipher;
import javax.crypto.KEM;
import javax.crypto.spec.GCMParameterSpec;

public final class CryptoService {
    private static final String ALGORITHM = "ML-KEM-768";
    private static final int AES_KEY_BYTES = 32;
    private static final int TAG_BITS = 128;

    public record EncryptedMessage(byte[] encapsulation, byte[] nonce, byte[] ciphertextAndTag) {}

    public KeyPair generateKeyPair() throws GeneralSecurityException {
        return KeyPairGenerator.getInstance(ALGORITHM).generateKeyPair();
    }

    public EncryptedMessage encrypt(PublicKey recipient, byte[] plaintext)
            throws GeneralSecurityException {
        var encapsulated = KEM.getInstance(ALGORITHM).newEncapsulator(recipient)
                .encapsulate(0, AES_KEY_BYTES, "AES");
        var cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, encapsulated.key());
        return new EncryptedMessage(encapsulated.encapsulation(), cipher.getIV(),
                cipher.doFinal(plaintext));
    }

    public byte[] decrypt(PrivateKey recipient, EncryptedMessage message)
            throws GeneralSecurityException {
        var key = KEM.getInstance(ALGORITHM).newDecapsulator(recipient)
                .decapsulate(message.encapsulation(), 0, AES_KEY_BYTES, "AES");
        var cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(TAG_BITS, message.nonce()));
        return cipher.doFinal(message.ciphertextAndTag());
    }
}
