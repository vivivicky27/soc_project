package pqc;

import java.awt.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.util.Base64;
import javax.crypto.AEADBadTagException;
import javax.swing.*;
import pqc.CryptoService.EncryptedMessage;

public final class DesktopApp {
    private final CryptoService crypto = new CryptoService();
    private final JFrame window = new JFrame("Post-Quantum Hybrid Encryption");
    private final JTextArea input = new JTextArea(10, 28);
    private final JTextArea output = new JTextArea(10, 28);
    private final JTextArea publicKey = new JTextArea(3, 28);
    private final JLabel status = new JLabel("Generate a recipient key pair to begin.");
    private KeyPair recipient;
    private EncryptedMessage outgoing;
    private EncryptedMessage incoming;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DesktopApp().show());
    }

    private void show() {
        input.setLineWrap(true);
        output.setLineWrap(true);
        publicKey.setLineWrap(true);
        output.setEditable(false);
        publicKey.setEditable(false);

        JPanel sender = panel("Sender", "Message to encrypt", input,
                button("Encrypt and Send", this::encrypt),
                button("Export Package", this::exportPackage));
        JPanel receiver = panel("Recipient", "Decrypted message", output,
                button("Generate Key Pair", this::generate),
                button("Verify RTL Forward NTT", this::verifyRtl),
                button("Import Package", this::importPackage),
                button("Decrypt", this::decrypt),
                button("Tamper and Try Decrypting", this::tamper));
        JPanel keyPanel = new JPanel(new BorderLayout());
        keyPanel.add(new JLabel("Recipient public key (Base64)"), BorderLayout.NORTH);
        keyPanel.add(new JScrollPane(publicKey), BorderLayout.CENTER);

        JPanel sides = new JPanel(new GridLayout(1, 2, 12, 0));
        sides.add(sender);
        sides.add(receiver);
        JPanel content = new JPanel(new BorderLayout(0, 12));
        content.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        content.add(keyPanel, BorderLayout.NORTH);
        content.add(sides, BorderLayout.CENTER);
        content.add(status, BorderLayout.SOUTH);
        window.setContentPane(content);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.pack();
        window.setLocationRelativeTo(null);
        window.setVisible(true);
    }

    private JPanel panel(String title, String label, JTextArea area, JButton... buttons) {
        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setBorder(BorderFactory.createTitledBorder(title));
        panel.add(new JLabel(label), BorderLayout.NORTH);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);
        JPanel actions = new JPanel(new GridLayout(0, 2, 4, 4));
        for (JButton button : buttons) {
            actions.add(button);
        }
        panel.add(actions, BorderLayout.SOUTH);
        return panel;
    }

    @FunctionalInterface
    private interface Action {
        void run() throws IOException, GeneralSecurityException;
    }

    private JButton button(String label, Action action) {
        JButton button = new JButton(label);
        button.addActionListener(event -> {
            try {
                action.run();
            } catch (AEADBadTagException e) {
                status.setText("Authentication failed. Check the package and recipient key.");
            } catch (IOException | GeneralSecurityException | IllegalStateException e) {
                status.setText(e.getMessage() == null ? "Operation failed." : e.getMessage());
            }
        });
        return button;
    }

    private void verifyRtl() {
        status.setText("Running RTL forward NTT verification...");
        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws Exception {
                return NttDemo.verify(java.nio.file.Path.of(".").toAbsolutePath());
            }

            @Override
            protected void done() {
                try {
                    status.setText(get());
                } catch (Exception e) {
                    Throwable cause = e.getCause() == null ? e : e.getCause();
                    status.setText("RTL verification failed: " + cause.getMessage());
                }
            }
        }.execute();
    }
    private void generate() throws GeneralSecurityException {
        recipient = crypto.generateKeyPair();
        outgoing = null;
        incoming = null;
        output.setText("");
        publicKey.setText(Base64.getEncoder().encodeToString(recipient.getPublic().getEncoded()));
        publicKey.setCaretPosition(0);
        status.setText("Key pair generated. Earlier packages require their original private key.");
    }

    private void encrypt() throws GeneralSecurityException {
        requireKey();
        byte[] plaintext = input.getText().getBytes(StandardCharsets.UTF_8);
        if (plaintext.length > PackageFile.MAX_PLAINTEXT_BYTES) {
            throw new IllegalStateException("The message exceeds the 1 MiB limit.");
        }
        outgoing = crypto.encrypt(recipient.getPublic(), plaintext);
        incoming = outgoing;
        output.setText("");
        status.setText("Encrypted package delivered to the recipient panel.");
    }

    private void exportPackage() throws IOException {
        if (outgoing == null) {
            throw new IllegalStateException("Encrypt a message before exporting.");
        }
        var chooser = new JFileChooser();
        chooser.setSelectedFile(new java.io.File("message.pqc"));
        if (chooser.showSaveDialog(window) == JFileChooser.APPROVE_OPTION) {
            var path = chooser.getSelectedFile().toPath();
            if (java.nio.file.Files.exists(path) && JOptionPane.showConfirmDialog(window,
                    "Replace the existing file?", "Export Package", JOptionPane.YES_NO_OPTION)
                    != JOptionPane.YES_OPTION) {
                return;
            }
            PackageFile.write(path, outgoing);
            status.setText("Encrypted package exported.");
        }
    }

    private void importPackage() throws IOException {
        var chooser = new JFileChooser();
        if (chooser.showOpenDialog(window) == JFileChooser.APPROVE_OPTION) {
            incoming = null;
            output.setText("");
            incoming = PackageFile.read(chooser.getSelectedFile().toPath());
            status.setText("Package imported. Select Decrypt.");
        }
    }

    private void requireKey() {
        if (recipient == null) {
            throw new IllegalStateException("Generate a recipient key pair first.");
        }
    }

    private void decrypt() throws GeneralSecurityException {
        decrypt(incoming);
    }

    private void decrypt(EncryptedMessage message) throws GeneralSecurityException {
        output.setText("");
        requireKey();
        if (message == null) {
            throw new IllegalStateException("Send or import an encrypted package first.");
        }
        output.setText(new String(crypto.decrypt(recipient.getPrivate(), message), StandardCharsets.UTF_8));
        status.setText("Authentication passed. Message decrypted.");
    }

    private void tamper() throws GeneralSecurityException {
        if (incoming == null) {
            throw new IllegalStateException("Send or import an encrypted package first.");
        }
        byte[] modified = incoming.ciphertextAndTag().clone();
        modified[0] ^= 1;
        decrypt(new EncryptedMessage(incoming.encapsulation(), incoming.nonce(), modified));
    }
}

