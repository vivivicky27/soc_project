package pqc;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** Software-scheduled forward NTT using the supplied RTL via Icarus Verilog. */
public final class NttDemo {
    private static final int Q = 3329;
    private NttDemo() {}

    public static int[] forward(int[] input, Path project, boolean rtl) throws Exception {
        if (input.length != 256) throw new IllegalArgumentException("Expected 256 coefficients.");
        int[] values = input.clone();
        for (int value : values) {
            if (value < 0 || value >= Q) throw new IllegalArgumentException("Coefficient out of range.");
        }
        Path work = Files.createTempDirectory("pqc-ntt-");
        try {
            Path executable = work.resolve("butterfly.vvp");
            if (rtl) run(project, List.of(tool("iverilog"), "-g2012", "-s", "ntt_layer_tb",
                    "-o", executable.toString(), project.resolve("rtl/ntt_butterfly.sv").toString(),
                    project.resolve("rtl/ntt_layer_tb.sv").toString()), work.resolve("compile.log"));
            int k = 1;
            for (int length = 128; length >= 2; length /= 2) {
                List<String> requests = new ArrayList<>();
                List<Integer> addresses = new ArrayList<>();
                for (int start = 0; start < 256; start += 2 * length) {
                    int zeta = power(17, Integer.reverse(k++) >>> 25);
                    for (int j = start; j < start + length; j++) {
                        addresses.add(j);
                        requests.add(values[j] + " " + values[j + length] + " " + zeta);
                        if (!rtl) {
                            int t = values[j + length] * zeta % Q;
                            int a = values[j];
                            values[j] = (a + t) % Q;
                            values[j + length] = (a - t + Q) % Q;
                        }
                    }
                }
                if (rtl) {
                    Path in = work.resolve("input.txt");
                    Path out = work.resolve("output.txt");
                    Files.deleteIfExists(out);
                    Files.write(in, requests, StandardCharsets.US_ASCII);
                    run(project, List.of(tool("vvp"), executable.toString(),
                            "+INPUT=" + in, "+OUTPUT=" + out), work.resolve("simulate.log"));
                    List<String> results = Files.readAllLines(out);
                    if (results.size() != 128) throw new IOException("Expected 128 RTL results.");
                    for (int i = 0; i < results.size(); i++) {
                        String[] pair = results.get(i).trim().split("\\s+");
                        if (pair.length != 2) throw new IOException("Invalid RTL response.");
                        int u = Integer.parseInt(pair[0]);
                        int v = Integer.parseInt(pair[1]);
                        if (u < 0 || u >= Q || v < 0 || v >= Q)
                            throw new IOException("RTL result out of range.");
                        int j = addresses.get(i);
                        values[j] = u;
                        values[j + length] = v;
                    }
                }
            }
            return values;
        } finally {
            try (var paths = Files.walk(work)) {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(path);
            }
        }
    }

    private static String tool(String name) {
        return System.getProperty("pqc." + name, name);
    }

    private static int power(int base, int exponent) {
        int result = 1;
        for (int i = 0; i < exponent; i++) result = result * base % Q;
        return result;
    }

    private static void run(Path directory, List<String> command, Path log) throws Exception {
        Process process = new ProcessBuilder(command).directory(directory.toFile())
                .redirectErrorStream(true).redirectOutput(log.toFile()).start();
        if (!process.waitFor(30, TimeUnit.SECONDS)) {
            process.destroyForcibly();
            process.waitFor();
            throw new IOException("RTL simulator timed out.");
        }
        if (process.exitValue() != 0)
            throw new IOException("RTL tool failed: " + Files.readString(log));
    }

    public static String verify(Path project) throws Exception {
        Random random = new Random(9433);
        for (int test = 0; test < 5; test++) {
            int[] input = new int[256];
            for (int j = 0; j < input.length; j++)
                input[j] = test == 0 ? 0 : test == 1 ? Q - 1 : random.nextInt(Q);
            int[] expected = forward(input, project, false);
            int[] actual = forward(input, project, true);
            if (!Arrays.equals(expected, actual))
                throw new IllegalStateException("RTL mismatch in test " + test);
        }
        return "PASS: 5 forward NTTs, 4,480 RTL butterflies, all 256 coefficients matched per test.";
    }

    public static void main(String[] args) throws Exception {
        System.out.println(verify(Path.of(args.length == 0 ? "." : args[0]).toAbsolutePath()));
    }
}

