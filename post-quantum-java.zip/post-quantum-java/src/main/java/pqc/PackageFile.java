package pqc;

import java.io.*;
import java.nio.file.*;
import pqc.CryptoService.EncryptedMessage;

public final class PackageFile {
    private static final int MAGIC = 0x50514331; // PQC1
    private static final int ENCAPSULATION_BYTES = 1088;
    private static final int NONCE_BYTES = 12;
    private static final int TAG_BYTES = 16;
    public static final int MAX_PLAINTEXT_BYTES = 1024 * 1024;

    private PackageFile() {}

    public static void write(Path path, EncryptedMessage message) throws IOException {
        int length = message.ciphertextAndTag().length;
        if (message.encapsulation().length != ENCAPSULATION_BYTES
                || message.nonce().length != NONCE_BYTES || !validLength(length)) {
            throw new IOException("Invalid encrypted package fields.");
        }
        try (var out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(path)))) {
            out.writeInt(MAGIC);
            out.writeInt(length);
            out.write(message.encapsulation());
            out.write(message.nonce());
            out.write(message.ciphertextAndTag());
        }
    }

    public static EncryptedMessage read(Path path) throws IOException {
        try (var in = new DataInputStream(new BufferedInputStream(Files.newInputStream(path)))) {
            if (in.readInt() != MAGIC) {
                throw new IOException("Unsupported encrypted package format.");
            }
            int length = in.readInt();
            if (!validLength(length)) {
                throw new IOException("Invalid ciphertext length.");
            }
            byte[] encapsulation = readField(in, ENCAPSULATION_BYTES);
            byte[] nonce = readField(in, NONCE_BYTES);
            byte[] ciphertext = readField(in, length);
            if (in.read() != -1) {
                throw new IOException("Unexpected trailing data.");
            }
            return new EncryptedMessage(encapsulation, nonce, ciphertext);
        } catch (EOFException e) {
            throw new IOException("The encrypted package is truncated.", e);
        }
    }

    private static boolean validLength(int length) {
        return length >= TAG_BYTES && length <= MAX_PLAINTEXT_BYTES + TAG_BYTES;
    }

    private static byte[] readField(DataInputStream in, int length) throws IOException {
        byte[] value = new byte[length];
        in.readFully(value);
        return value;
    }
}
