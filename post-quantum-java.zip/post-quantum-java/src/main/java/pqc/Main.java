package pqc;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.util.Arrays;
import javax.crypto.AEADBadTagException;
import pqc.CryptoService.EncryptedMessage;

public final class Main {
    public static void main(String[] args) throws GeneralSecurityException {
        var crypto = new CryptoService();
        var recipient = crypto.generateKeyPair();
        byte[] original = "Hello, Java!".getBytes(StandardCharsets.UTF_8);
        var encrypted = crypto.encrypt(recipient.getPublic(), original);
        byte[] recovered = crypto.decrypt(recipient.getPrivate(), encrypted);
        if (!Arrays.equals(original, recovered)) {
            throw new IllegalStateException("The recovered message differs from the original.");
        }
        System.out.println("Recovered: " + new String(recovered, StandardCharsets.UTF_8));

        byte[] modified = encrypted.ciphertextAndTag().clone();
        modified[0] ^= 1;
        expectRejection(crypto, recipient.getPrivate(),
                new EncryptedMessage(encrypted.encapsulation(), encrypted.nonce(), modified),
                "Modified ciphertext");
        expectRejection(crypto, crypto.generateKeyPair().getPrivate(), encrypted, "Wrong private key");
    }

    private static void expectRejection(CryptoService crypto, PrivateKey key,
            EncryptedMessage encrypted, String scenario) throws GeneralSecurityException {
        try {
            crypto.decrypt(key, encrypted);
        } catch (AEADBadTagException expected) {
            System.out.println(scenario + ": rejected by AES-GCM authentication.");
            return;
        }
        throw new IllegalStateException(scenario + " unexpectedly decrypted.");
    }
}
